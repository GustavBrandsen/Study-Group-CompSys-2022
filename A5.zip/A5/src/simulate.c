//mangler sllw
#include "simulate.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


long int simulate(struct memory *mem, struct assembly *as, int start_addr, FILE *log_file)
{
    int pc = start_addr - 4;
    int r[32] = { 0 };
    long int num_insns = 0;

    int rd;
    int funct3;
    int funct7;
    int rs1;
    int rs2;
    int imm1;
    int imm2;
    int imm3;
    int imm4;
    int imm;

    int insn = memory_rd_w(mem, pc);

    char log_output[32];
    char *r_NAMES[32] = { "zero","ra","sp","gp","tp","t0","t1","t2","s0","s1","a0","a1","a2","a3","a4","a5","a6","a7","s2","s3","s4","s5","s6","s7","s8","s9","s10","s11","t3","t4","t5","t6" };
    int i = -1;
    while (1) {
        i += 1;
        pc = pc + 4;
        // printf("\nSTART PC : %x\n", pc);
        num_insns += 1;
        // We get the instruction(insn)
        insn = memory_rd_w(mem, pc);
        // // printf("insn: %d \n", memory_rd_w(mem, pc));


        // We want to decode the instruction (insn) to variables
        int opcode = insn & 127; // Max 127 int
        //

        if (opcode == FMT_I3 || opcode == FMT_I19 || opcode == FMT_I27 || opcode == FMT_I103 || opcode == FMT_I115) {
            rd = (insn >> 7) & 31; // Start from 7th bit, max 31 int
            funct3 = (insn >> 12) & 7; // Start from 12th bit, max 7 int
            rs1 = (insn >> 15) & 31; // Start from 15th bit, max 31 int
            imm = (insn >> 20) & 4095; // Start from 20th bit, max 4095 int

            switch (opcode)
            {
                case FMT_I3:
                    switch (funct3)
                    {
                        case LB:
                            r[rd] = memory_rd_b(mem, (r[rs1] + imm));
                            sprintf((char *)&log_output, "%s,%d(%s)", r_NAMES[rd], imm, r_NAMES[rs1]);
                            fprintf(log_file, "%-3d %s %5x : %8x    %-4s %-20s %-4s R[%d] <- %x\n", i, /*JUMP*/"", pc, insn, "LBU", log_output, /*BETINGET JUMP*/"", rd, r[rd]);
                            break;

                        case LH:
                            r[rd] = memory_rd_h(mem, (r[rs1] + imm));
                            sprintf((char *)&log_output, "%s,%d(%s)", r_NAMES[rd], imm, r_NAMES[rs1]);
                            fprintf(log_file, "%-3d %s %5x : %8x    %-4s %-20s %-4s R[%d] <- %x\n", i, /*JUMP*/"", pc, insn, "LBU", log_output, /*BETINGET JUMP*/"", rd, r[rd]);
                            break;

                        case LW:
                            r[rd] = memory_rd_w(mem, (r[rs1] + imm));
                            sprintf((char *)&log_output, "%s,%d(%s)", r_NAMES[rd], imm, r_NAMES[rs1]);
                            fprintf(log_file, "%-3d %s %5x : %8x    %-4s %-20s %-4s R[%d] <- %x\n", i, /*JUMP*/"", pc, insn, "LBU", log_output, /*BETINGET JUMP*/"", rd, r[rd]);
                            break;

                        case LBU:
                            r[rd] = memory_rd_b(mem, (r[rs1] + imm));
                            sprintf((char *)&log_output, "%s,%d(%s)", r_NAMES[rd], imm, r_NAMES[rs1]);
                            fprintf(log_file, "%-3d %s %5x : %8x    %-4s %-20s %-4s R[%d] <- %x\n", i, /*JUMP*/"", pc, insn, "LBU", log_output, /*BETINGET JUMP*/"", rd, r[rd]);
                            break;

                        case LHU:
                            // printf("LHU\n");
                            // printf("r[rd]: %d\n", r[rd]);
                            // printf("imm: %d\n", imm);
                            // printf("r[rs1]: %d\n", r[rs1]);
                            // printf("r[rs1] + imm: %d\n", imm + r[rs1]);
                            r[rd] = memory_rd_h(mem, (r[rs1] + imm));
                            // printf("r[rd]: %d\n", r[rd]);
                            break;

                        default:
                            break;
                    }
                    break;

                case FMT_I19:
                    switch (funct3)
                    {
                        case ADDI:
                            // printf("ADDI\n");
                            r[rd] = r[rs1] + imm;
                            break;

                        case SLLI:
                            // printf("SLLI\n");
                            r[rd] = r[rs1] << imm;
                            break;

                        case SLTI:
                            // printf("SLTI\n");
                            r[rd] = (r[rs1] < imm) ? 1 : 0;
                            break;

                        case SLTIU:
                            // printf("SLTIU\n");
                            r[rd] = (r[rs1] < imm) ? 1 : 0;
                            break;

                        case XORI:
                            // printf("XORI\n");
                            r[rd] = r[rs1] ^ imm;
                            break;

                        case 5:
                            switch (imm)
                            {
                                case SRLI:
                                    // printf("SRLI\n");
                                    r[rd] = r[rs1] >> imm;
                                    break;

                                case SRAI:
                                    // printf("SRAI\n");
                                    r[rd] = r[rs1] >> imm;
                                    break;

                                default:
                                    break;
                            }
                            break;

                        case ORI:
                            // printf("ORI\n");
                            r[rd] = r[rs1] || imm;
                            break;

                        case ANDI:
                            // printf("ANDI\n");
                            r[rd] = r[rs1] && imm;
                            break;

                        default:
                            break;
                    }
                    break;

                case FMT_I103: // JALR 
                    // printf("JALR\n");
                    pc = (r[rs1] + imm) - 4;
                    break;

                case FMT_I115:
                    switch (imm)
                    {
                        case ECALL:
                            // printf("r[17]: %d\n", r[17]);
                            switch (r[17])
                            {
                                case 1:
                                    r[17] = getchar();
                                    break;

                                case 2:
                                    putchar(r[16]);
                                    break;

                                case 3:
                                    return num_insns;
                                    break;

                                case 93:
                                    return num_insns;
                                    break;

                                default:
                                    break;
                            }
                            // printf("ECALL\n");
                            break;

                        default:
                            break;
                    }
                    break;

                default:
                    break;
            }

        } else if (opcode == FMT_U23 || opcode == FMT_U55) {
            rd = (insn >> 7) & 31; // Start from 7th bit, max 31 int
            imm = (insn >> 12) << 12; // Start from 20th bit, max 4095 int MAYBE "<< 12"

            switch (opcode)
            {
                case FMT_U23: //AUIPC 
                    // printf("AUIPC\n");
                    r[rd] = pc + imm;
                    break;

                case FMT_U55: //LUI 
                    // printf("LUI\n");
                    r[rd] = imm;
                    break;

                default:
                    break;
            }
        } else if (opcode == FMT_S35) {
            funct3 = (insn >> 12) & 7; // Start from 12th bit, max 7 int
            rs1 = (insn >> 15) & 31; // Start from 15th bit, max 31 int
            rs2 = (insn >> 20) & 31; // Start from 20th bit, max 31 int
            imm1 = (insn >> 7) & 31; // Start from 7th bit, max 31 int
            imm2 = (insn >> 25) & 4095; // Start from 20th bit, max 4095 int
            imm = (imm2 << 5) | imm1;

            switch (funct3)
            {
                case SB:
                    // printf("SB\n");
                    memory_wr_b(mem, r[rs1] + imm, r[rs2]);
                    break;

                case SH:
                    // printf("SH\n");
                    memory_wr_h(mem, r[rs1] + imm, r[rs2]);
                    break;

                case SW:
                    // printf("SW\n");
                    memory_wr_w(mem, r[rs1] + imm, r[rs2]);
                    break;

                default:
                    break;
            }
        } else if (opcode == FMT_R51 || opcode == FMT_R59) {
            rd = (insn >> 7) & 31; // Start from 7th bit, max 31 int
            funct3 = (insn >> 12) & 7; // Start from 12th bit, max 7 int
            rs1 = (insn >> 15) & 31; // Start from 15th bit, max 31 int
            rs2 = (insn >> 20) & 31; // Start from 20th bit, max 31 int
            funct7 = (insn >> 25) & 127; // Start from 25th bit, max 127 int

            switch (opcode)
            {
                case FMT_R51:
                    switch (funct3)
                    {
                        case 0:
                            switch (funct7)
                            {
                                case ADD:
                                    // printf("ADD\n");
                                    r[rd] = r[rs1] + r[rs2];
                                    break;

                                case SUB:
                                    // printf("SUB\n");
                                    r[rd] = r[rs1] - r[rs2];
                                    break;

                                default:
                                    break;
                            }
                            break;

                        case 1: //SLL 
                            // printf("SLL\n");
                            r[rd] = r[rs1] << r[rs2];
                            break;

                        case 2: //SLT 
                            // printf("SLT\n");
                            r[rd] = (r[rs1] < r[rs2]) ? 1 : 0;
                            break;

                        case 3: //SLTU 
                            // printf("SLTU\n");
                            r[rd] = (r[rs1] < r[rs2]) ? 1 : 0;
                            break;

                        case 4: //XOR 
                            // printf("XOR\n");
                            r[rd] = r[rs1] ^ r[rs2];
                            break;

                        case 5:
                            switch (funct7)
                            {
                                case SRL:
                                    // printf("SRL\n");
                                    r[rd] = r[rs1] >> r[rs2];
                                    break;

                                case SRA:
                                    // printf("SRA\n");
                                    r[rd] = r[rs1] >> r[rs2];
                                    break;

                                default:
                                    break;
                            }
                            break;

                        case OR:
                            // printf("OR\n");
                            r[rd] = r[rs1] || r[rs2];
                            break;

                        case 7:
                            switch (funct7)
                            {
                                case AND:
                                    // printf("AND\n");
                                    r[rd] = r[rs1] && r[rs2];
                                    break;

                                case REMU:
                                    // printf("REMU\n");
                                    r[rd] = r[rs1] % r[rs2];
                                    break;

                                default:
                                    break;
                            }
                        default:
                            break;
                    }
                    break;

                default:
                    break;
            }
        } else if (opcode == FMT_SB99) {
            funct3 = (insn >> 12) & 7; // Start from 12th bit, max 7 int
            rs1 = (insn >> 15) & 31; // Start from 15th bit, max 31 int
            rs2 = (insn >> 20) & 31; // Start from 20th bit, max 31 int
            imm1 = (insn >> 7) & 1;
            imm2 = (insn >> 8) & 15;
            imm3 = (insn >> 25) & 63;
            imm4 = (insn >> 31) & 1;
            imm = ((((imm1)) << 6 | imm3) << 4 | imm2) << 1;

            if (imm4)
            {
                imm = imm | -(imm4 << 12);
            } else {
                imm = imm | (imm4 << 12);
            }

            switch (funct3)
            {
                case BEQ:
                    // printf("BEQ\n");
                    // printf("IMM: %d\n", (imm));
                    if (r[rs1] == r[rs2])
                    {
                        pc = pc + imm - 4;
                    }
                    break;

                case BNE:
                    // printf("BNE\n");
                    // printf("IMM: %d\n", (imm));
                    if (r[rs1] != r[rs2])
                    {
                        pc = pc + imm - 4;
                    }
                    break;

                case BLT:
                    // printf("BLT\n");
                    if (r[rs1] < r[rs2])
                    {
                        pc = pc + imm;
                    }
                    break;

                case BGE:
                    // printf("BGE\n");
                    if (r[rs1] >= r[rs2])
                    {
                        pc = pc + imm;
                    }
                    break;

                case BLTU:
                    // printf("BLTU\n");
                    if (r[rs1] < r[rs2])
                    {
                        pc = pc + imm;
                    }
                    break;

                case BGEU:
                    // printf("BGEU\n");
                    if (r[rs1] >= r[rs2])
                    {
                        pc = pc + imm;
                    }
                    break;

                default:
                    break;
            }
        } else if (opcode == FMT_UJ111) {
            rd = (insn >> 7) & 31; // Start from 7th bit, max 31 int
            imm1 = ((insn >> 12) & 255); // Start from 20th bit, max 4095 int
            imm2 = ((insn >> 20) & 1);
            imm3 = ((insn >> 21) & 1023);
            imm4 = (insn >> 31) & 1;
            imm = ((imm1 << 12) | (imm2 << 11) | (imm3 << 1) | 0);

            if (imm4)
            {
                imm = imm | -(imm4 << 20);
            } else {
                imm = imm | (imm4 << 20);
            }


            // // printf("[10:1]: %d\n", imm3);
            // // printf("[11]: %d\n", imm2);
            // // printf("[19:12]: %d\n", imm1);
            // // printf("[20]: %d\n", imm4);

            switch (opcode)
            {
                case FMT_UJ111: //JAL 
                    // printf("JAL\n");
                    r[rd] = pc + 4;
                    pc = pc + imm - 4;
                    break;

                default:
                    break;
            }
        }
    }
    return num_insns;
}
